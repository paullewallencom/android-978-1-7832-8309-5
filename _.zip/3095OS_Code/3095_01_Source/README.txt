Creating Dynamic UI with Android Fragments
Chapter 1: Fragments and UI Modularization

Projects created with Android Studio version 0.2.4 
(the version publicly available on 15-August-2013)

Projects contained in this folder

ActivityImplementation\AndroidBooksProject
- The Activity-based application.
- Represents the application as the chapter begins prior to using Fragments.

FragmentImplementation\AndroidBooksProject
- The Fragment-based application (native Fragment support)
- Represents the application at the end of the chapter

FragmentSupportLibImplementation\AndroidBooksProject
- The Fragment-based application (uses support library)
- Represents the application at the end of the chapter


**** 
**** See the README.txt in each project's folder for more details on that project