Creating Dynamic UI with Android Fragments
Chapter 1: Fragments and UI Modularization

This project is the Activity-based application. This project represents the application as the chapter begins prior to using Fragments.

Project created with Android Studio version 0.2.4 (the version publicly available on 15-August-2013)
Available at: http://developer.android.com/sdk/installing/studio.html

NOTE: When opening the project Android Studio will sometimes report a "NullPointerException". This can be ignored; the project will open and build fine.