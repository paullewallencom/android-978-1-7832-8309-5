Creating Dynamic UI with Android Fragments
Chapter 3: Fragment lifecycle and specialization

This project represents the application as it appears at the end of the "DialogFragment" section

Project created with Android Studio version 0.2.4 (the version publicly available on 15-August-2013)
Available at: http://developer.android.com/sdk/installing/studio.html

NOTE: When opening the project Android Studio will sometimes report a "NullPointerException". This can be ignored; the project will open and build fine.