Creating Dynamic UI with Android Fragments
Chapter 3: Fragment lifecycle and specialization

Projects created with Android Studio version 0.2.4 
(the version publicly available on 15-August-2013)

Projects contained in this folder

DialogFragment\ExerciseDialogFragmentsProject
- Represents the application as it appears at the end of the "DialogFragment" section

UIFlexibilitySupportLib\AndroidBooksProject
- Represents the application as it appears at the end of the "ListFragment" section


**** 
**** See the README.txt in each project's folder for more details on that project