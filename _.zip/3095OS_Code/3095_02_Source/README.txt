Creating Dynamic UI with Android Fragments
Chapter 2: Fragments and UI Flexibility

Projects created with Android Studio version 0.2.4 
(the version publicly available on 15-August-2013)

Projects contained in this folder

UIFlexibility\AndroidBooksProject
- Represents the application at the end of the "Design Fragments for flexibility" section.
- Targets only devices with native Fragment support

UIFlexibilitySupportLib\AndroidBooksProject
- Represents the application at the end of the "Design Fragments for flexibility" section.
- Uses Android support library to support devices without native Fragment capability

ProtectAgainstUnexpected\AndroidBooksProject
- Represents the application at the end of the "Fragments protect against the unexpected" section.
- Targets only devices with native Fragment support

ProtectAgainstUnexpectedSupportLib\AndroidBooksProject
- Represents the application at the end of the "Fragments protect against the unexpected" section.
- Uses Android support library to support devices without native Fragment capability


**** 
**** See the README.txt in each project's folder for more details on that project