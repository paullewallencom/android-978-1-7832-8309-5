Creating Dynamic UI with Android Fragments
Chapter 2: Fragments and UI Flexibility

This project represents the application as it appears at the end of the "Fragments protect against the unexpected" section

This project is the application built for platforms that natively support Fragments (API Level >= 11).
To see this same application built to support pre-API Level 11 devices, see the project in the ProtectAgainstUnexpectedSupportLib folder.

Project created with Android Studio version 0.2.4 (the version publicly available on 15-August-2013)
Available at: http://developer.android.com/sdk/installing/studio.html

NOTE: When opening the project Android Studio will sometimes report a "NullPointerException". This can be ignored; the project will open and build fine.