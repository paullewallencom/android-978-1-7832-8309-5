package com.jwhh.fragments;

/**
 * Created by Jim on 8/14/13.
 */
public interface OnSelectedBookChangeListener {
  void onSelectedBookChanged(int bookIndex);
}
