Creating Dynamic UI with Android Fragments
Chapter 4: Working with Fragment Transactions

Projects created with Android Studio version 0.2.4 
(the version publicly available on 15-August-2013)

Projects contained in this folder

SwipeNavigation\BookBrowserProject
- Represents the application created in the "Making navigation fun with swipe" section

TabNavigation\ExerciseTabsProject
- Represents the application created in the "Random navigation with tabs" section

DropdownNavigation\ExerciseDropdownNavProject
- Represents the application created in the "Providing direct access with dropdown list navigation" section

**** 
**** See the README.txt in each project's folder for more details on that project